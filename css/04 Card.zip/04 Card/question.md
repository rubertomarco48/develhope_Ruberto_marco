Starting from the card that you created in the HTML exercise, add the CSS properties. Look at the layout in the example.png.

**Suggestion**:

Try to make the pic inside the card responsive, so that it fits its container.
